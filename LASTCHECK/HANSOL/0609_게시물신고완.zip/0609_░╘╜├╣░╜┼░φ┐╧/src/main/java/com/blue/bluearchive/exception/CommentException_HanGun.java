package com.blue.bluearchive.exception;

public class CommentException_HanGun {
}
