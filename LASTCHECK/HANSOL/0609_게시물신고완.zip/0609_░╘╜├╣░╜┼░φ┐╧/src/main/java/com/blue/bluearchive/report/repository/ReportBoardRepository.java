package com.blue.bluearchive.report.repository;

import com.blue.bluearchive.report.entity.ReportBoard;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportBoardRepository extends JpaRepository<ReportBoard,Integer> {
}
