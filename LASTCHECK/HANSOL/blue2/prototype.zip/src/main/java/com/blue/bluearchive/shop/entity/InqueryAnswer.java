package com.blue.bluearchive.shop.entity;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
@Entity
@Getter @Setter
@Table(name = "InqueryAnswer")
public class InqueryAnswer extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "inqueryAnswer_id")
    private int id;

    @OneToOne
    @JoinColumn(name = "inquery_id")
    private Inquery inquery;

    @Column(name = "inqueryAnswer_content", length = 300, nullable = false)
    private String content;
}

