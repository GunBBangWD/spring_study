package com.blue.bluearchive.constant;

public enum ItemCategory {
    ALL,CLOTHES,FOOD,EASYFOOD,EQUIPMENT
}
