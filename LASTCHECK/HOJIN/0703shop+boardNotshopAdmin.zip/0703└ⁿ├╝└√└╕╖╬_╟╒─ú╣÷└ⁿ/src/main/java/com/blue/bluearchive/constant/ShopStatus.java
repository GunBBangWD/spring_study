package com.blue.bluearchive.constant;

public enum ShopStatus {
    SELLER,SELLERWAITING,CONSUMER
}
