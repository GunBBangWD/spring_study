package com.blue.bluearchive.shop.repository;

public class OrderItemRepositoryImpl {

}
