package com.blue.bluearchive.user.logincontroller;

import org.springframework.stereotype.Controller;

@Controller
public class UserLoginController {


}
