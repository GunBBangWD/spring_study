package com.blue.bluearchive.constant;

public enum OrderStatus {
    ORDER,CANCEL
}
