package com.blue.bluearchive.board.repository.formRepository;

import com.blue.bluearchive.board.entity.CategoryBodyImg;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryBodyImgRepository extends JpaRepository<CategoryBodyImg,Integer> {
}
