package com.blue.bluearchive.board.dto;

import lombok.Data;

@Data
public class BoardSearchDto {
    private String searchBy;
    private String searchQuery="";

}
