package com.blue.bluearchive.constant;

public enum Role {
    USER,ADMIN
}
