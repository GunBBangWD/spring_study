package com.blue.bluearchive.constant;

public enum OAuthProvider {
    KAKAO, NAVER
}
