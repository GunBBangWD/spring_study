package com.blue.bluearchive.board.service;

import com.blue.bluearchive.board.dto.BoardDto;

public interface BoardServiceForm {
    void createBoard(BoardDto boardDto);
}
