package com.blue.bluearchive.naver_kakao.config;

public class WebSecurityConfigurerAdapter {
}
