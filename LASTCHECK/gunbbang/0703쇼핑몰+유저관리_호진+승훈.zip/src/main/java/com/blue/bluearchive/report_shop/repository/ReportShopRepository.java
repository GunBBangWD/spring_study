package com.blue.bluearchive.report_shop.repository;

import com.blue.bluearchive.report_shop.entity.ReportShop;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportShopRepository extends JpaRepository<ReportShop,Integer> {


}
