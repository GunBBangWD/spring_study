package com.blue.bluearchive.constant;

public enum OrderSellerStatus {
    ORDERING, DELIVERING, DELIVERED, CANCEL, REFUND, REFUNDED
}
