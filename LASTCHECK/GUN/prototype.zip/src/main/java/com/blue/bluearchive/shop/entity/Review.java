package com.blue.bluearchive.shop.entity;

import com.blue.bluearchive.shop.entity.BaseEntity;
import com.blue.bluearchive.shop.entity.Item;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="review")
@Getter @Setter
@ToString
public class Review extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "review_id")
    private int reviewId;

    @ManyToOne
    @JoinColumn(name = "item_id")
    private Item item;

    @Column(name = "review_content", length = 300, nullable = false)
    private String content;

    @Column(name = "review_reportsCount", nullable = false)
    private int reportsCount;
}
