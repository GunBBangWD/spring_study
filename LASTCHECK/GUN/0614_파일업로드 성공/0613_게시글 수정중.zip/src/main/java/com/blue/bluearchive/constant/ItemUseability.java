package com.blue.bluearchive.constant;

public enum ItemUseability {
    ABLE,DISABLE
}
