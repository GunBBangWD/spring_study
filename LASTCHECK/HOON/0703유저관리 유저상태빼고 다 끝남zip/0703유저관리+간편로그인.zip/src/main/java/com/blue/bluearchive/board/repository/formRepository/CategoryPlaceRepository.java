package com.blue.bluearchive.board.repository.formRepository;

import com.blue.bluearchive.board.entity.CategoryPlace;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryPlaceRepository extends JpaRepository<CategoryPlace,Integer> {
}
