package com.blue.bluearchive.constant;

public enum ItemSellStatus {
    SELL,SOLD_OUT
}
