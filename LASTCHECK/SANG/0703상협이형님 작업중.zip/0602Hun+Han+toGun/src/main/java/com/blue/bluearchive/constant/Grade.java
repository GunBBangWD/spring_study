package com.blue.bluearchive.constant;

public enum Grade {
    BRONZE,SILVER,GOLD
}
