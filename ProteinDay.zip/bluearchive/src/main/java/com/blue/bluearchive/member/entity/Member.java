package com.blue.bluearchive.member.entity;

import com.blue.bluearchive.constant.Role;
import com.blue.bluearchive.member.dto.MemberFormDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.security.crypto.password.PasswordEncoder;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "member")
@Getter
@Setter
@ToString
public class Member {
    @Id
    @Column(name = "member_idx")
    private long memberIdx;

    @Column(name = "member_id", nullable = false, length = 20)
    private String memberId;

    @Column(name = "reg_time")
    private LocalDateTime regTime;

    @Column(name = "update_time")
    private LocalDateTime updateTime;

    @Column(name = "created_by", length = 255)
    private String createdBy;

    @Column(name = "modified_by", length = 255)
    private String modifiedBy;

    @Column(name = "member_address", length = 255)
    private String memberAddress;

    @Column(name = "member_email", nullable = false, length = 255, unique = true)
    private String memberEmail;

    @Column(name = "member_name", length = 255)
    private String memberName;

    @Column(name = "member_password", length = 255)
    private String memberPassword;

   @Enumerated(EnumType.STRING)
    private Role role;
    public static Member createMember(MemberFormDto memberFormDto, PasswordEncoder passwordEncoder) {
        Member member = new Member();
        member.setMemberName(memberFormDto.getMemberName());
        member.setMemberEmail(memberFormDto.getMemberEmail());
        member.setMemberAddress(memberFormDto.getMemberAddress());
        String password = passwordEncoder.encode(memberFormDto.getMemberPassword());
        member.setMemberPassword(password);
        member.setRole(Role.ADMIN);
        return member;
    }
}
