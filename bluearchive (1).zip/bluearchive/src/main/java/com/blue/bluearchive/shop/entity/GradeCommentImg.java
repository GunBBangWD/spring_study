package com.blue.bluearchive.shop.entity;

import com.blue.bluearchive.member.entity.GradeComment;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "grade_comment_img")
@Getter @Setter
public class GradeCommentImg {

    @Id
    @Column(name = "grade_comment_img_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String imgName; //이미지 파일명
    private String oriImgName; //원본 이미지 파일명
    private String imgUrl; //이미지 조회 경로
    private String repimgYn; //대표 이미지 여부

    // 양방향 관계가 되어버림
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="grade_comment_id")
    private GradeComment gradeComment;

    public void updateItemImg(String oriImgName,String imgName,String imgUrl){
        this.oriImgName=oriImgName;
        this.imgName=imgName;
        this.imgUrl=imgUrl;
    }

}
