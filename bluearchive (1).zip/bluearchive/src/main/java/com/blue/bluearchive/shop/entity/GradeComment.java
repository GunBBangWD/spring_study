package com.blue.bluearchive.member.entity;

import com.blue.bluearchive.constant.Grade;
import com.blue.bluearchive.constant.Role;
import com.blue.bluearchive.shop.entity.BaseEntity;
import com.blue.bluearchive.member.dto.MemberFormDto;
import com.blue.bluearchive.shop.entity.Item;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.security.crypto.password.PasswordEncoder;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="grade_comment")
@Getter @Setter
@ToString
public class GradeComment extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "grade_comment_id")
    private int commentId;

    @ManyToOne
    @JoinColumn(name = "item_id")
    private Item item;

    @Column(name = "grade_comment_created_by", length = 10, nullable = false)
    private String commentCreatedBy;

    @Column(name = "grade_comment_content", length = 300, nullable = false)
    private String commentContent;

    @Column(name = "grade_comment_time", nullable = false)
    private Timestamp commentTime;

    @Column(name = "grade_comment_reportsCount", nullable = false)
    private int commentReportsCount;
}
