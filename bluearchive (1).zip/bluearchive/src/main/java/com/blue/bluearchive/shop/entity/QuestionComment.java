package com.blue.bluearchive.shop.entity;

import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "question_comment")
public class QuestionComment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "question_comment_id")
    private int commentId;
    @ManyToOne
    @JoinColumn(name = "item_id")
    private Item item;

    @Column(name = "question_comment_created_by", length = 10, nullable = false)
    private String commentCreatedBy;

    @Column(name = "question_comment_content", length = 300, nullable = false)
    private String commentContent;

    @Column(name = "question_comment_time", nullable = false)
    private Timestamp commentTime;

}